mgraphics.init();
mgraphics.relative_coords = 1; // allows for 0-1 coords
mgraphics.autofill = 0;

g = new Global("rings");

var max_size = 0.9;

var mouse = new Point();

var dragging = false;
var hiddenText = false;

function bang(){
    mgraphics.redraw();
}

function paint(){
  drawAlignmentCompass(0.3);
  for(var i = 0; i < g.rings.length; i++){
    g.rings[i].update();
    g.rings[i].display();
  }

  for(var i = 0; i < g.rings.length; i++){
    g.rings[i].drawControl();
    g.rings[i].drawText();
  }
}

function drawAlignmentCompass(alpha){
  with(mgraphics){
    //Main Boundary
    ellipse(-max_size,max_size,max_size*2,max_size*2);

    //Alignment Lines
    var line_point = new Point(0,max_size);
    for(var i = 0; i < 8; i++){
      move_to(0,0);
      line_to(line_point.x,line_point.y);
      line_point = line_point.rotate(Math.PI/4);
      stroke_with_alpha(alpha);
    }

    var line_point = new Point(0,max_size-0.2);
    line_point = line_point.rotate(Math.PI/8);
    for(var i = 0; i < 8; i++){
      move_to(0,0);
      line_to(line_point.x,line_point.y);
      line_point = line_point.rotate(Math.PI/4);
      stroke_with_alpha(alpha);
    }

    move_to(max_size - 0.05,0);
    set_line_width(0.1);
    rel_line_to(0.1,0);
    set_line_width(0.01);//set line width

    if(!hiddenText){
      move_to(max_size + 0.02,-text_measure("Θ = 0")[1]/getHeight());
      show_text("Θ = 0");
    }

    identity_matrix();
  }
}

function Point(x,y){
  this.x = x;
  this.y = y;

  this.rotate = function(theta){
    new_point = new Point();
    new_point.x = this.x * Math.cos(theta) - this.y * Math.sin(theta);
    new_point.y = this.x * Math.sin(theta) + this.y * Math.cos(theta);
    return new_point;
  }
}

function getWidth(){
  return this.box.rect[2] - this.box.rect[0];
}

function getHeight(){
  return this.box.rect[3] - this.box.rect[1];
}
